The `record_batch_*` benchmarks in this section are written using
``pyperf`` library, created by Victor Stinner. For more information on
how to get reliable results of test runs please consult
https://pyperf.readthedocs.io/en/latest/run_benchmark.html.

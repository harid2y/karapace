ClusterMetadata
===========

.. autoclass:: kafka.cluster.ClusterMetadata
    :members:
